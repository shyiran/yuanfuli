<?php

namespace App\Http\Controllers\v2\Weixin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class UserController extends Controller
{
    //获取Token
    public function getToken ()
    {

        return "DDDDDDDDD";
    }


}
